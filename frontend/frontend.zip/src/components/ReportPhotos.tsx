import { useEffect, useRef, useState } from "react";
import {
  getReportPhotos,
  getReportPhotoPreview,
  uploadReportPhoto,
} from "../api/photos";
import type { ReportPhoto } from "../types/photos";

type ReportPhotosProps = {
  reportId: string;
  status: string;
};

function errorMessage(error: unknown): string {
  return error instanceof Error
    ? error.message
    : "Something went wrong. Please try again.";
}

function PhotoPreview({
  reportId,
  photo,
}: {
  reportId: string;
  photo: ReportPhoto;
}) {
  const [url, setUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const mounted = useRef(false);
  const busy = useRef(false);

  useEffect(() => {
    mounted.current = true;

    return () => {
      mounted.current = false;
    };
  }, []);

  async function openPreview() {
    if (busy.current) return;

    busy.current = true;
    setLoading(true);
    setError("");
    setUrl(null);

    try {
      const preview = await getReportPhotoPreview(
        reportId,
        photo.id,
      );

      if (!mounted.current) return;

      if (preview.photo_id !== photo.id) {
        throw new Error("The photo preview could not be verified.");
      }

      const parsedUrl = new URL(preview.url);

      if (parsedUrl.protocol !== "https:") {
        throw new Error("The photo preview address is invalid.");
      }

      setUrl(parsedUrl.href);
    } catch (caught) {
      if (mounted.current) {
        setError(errorMessage(caught));
      }
    } finally {
      busy.current = false;

      if (mounted.current) {
        setLoading(false);
      }
    }
  }

  return (
    <div className="report-photo-card">
      <p>
        Uploaded: {new Date(photo.created_at).toLocaleString()}
        {" · "}
        {Math.ceil(photo.byte_size / 1024)} KiB
      </p>

      <button
        type="button"
        disabled={loading}
        onClick={() => void openPreview()}
      >
        {loading
          ? "Loading photo..."
          : url
            ? "Refresh photo preview"
            : "View photo"}
      </button>

      {error && (
        <p className="form-message" role="alert">
          {error}
        </p>
      )}

      {url && (
        <img
          className="report-photo-image"
          src={url}
          alt="Road condition submitted as report evidence"
          referrerPolicy="no-referrer"
          onError={() => {
            setUrl(null);
            setError(
              "The preview could not be loaded or may have expired. " +
                "Click View photo to request another preview.",
            );
          }}
        />
      )}
    </div>
  );
}

export default function ReportPhotos({
  reportId,
  status,
}: ReportPhotosProps) {
  const [photos, setPhotos] = useState<ReportPhoto[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [refreshRequired, setRefreshRequired] = useState(false);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [localPreview, setLocalPreview] = useState<string | null>(null);

  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const mounted = useRef(false);
  const busy = useRef(false);
  const localPreviewRef = useRef<string | null>(null);

  useEffect(() => {
    mounted.current = true;

    return () => {
      mounted.current = false;

      if (localPreviewRef.current) {
        URL.revokeObjectURL(localPreviewRef.current);
        localPreviewRef.current = null;
      }
    };
  }, []);

  function clearSelection() {
    if (localPreviewRef.current) {
      URL.revokeObjectURL(localPreviewRef.current);
      localPreviewRef.current = null;
    }

    setSelectedFile(null);
    setLocalPreview(null);
  }

  function selectPhoto(file: File | undefined) {
    if (!file || busy.current) return;

    clearSelection();
    setError("");
    setMessage("");

    if (!["image/jpeg", "image/png"].includes(file.type)) {
      setError("Please select a JPEG or PNG photo.");
      return;
    }

    if (file.size === 0 || file.size > 3 * 1024 * 1024) {
      setError("Please select a non-empty photo of 3 MiB or smaller.");
      return;
    }

    const previewUrl = URL.createObjectURL(file);

    localPreviewRef.current = previewUrl;
    setSelectedFile(file);
    setLocalPreview(previewUrl);
  }

  async function refreshPhotos() {
    if (busy.current) return;

    busy.current = true;
    setLoading(true);
    setError("");
    setMessage("");

    try {
      const result = await getReportPhotos(reportId);

      if (!mounted.current) return;

      if (result.some((photo) => photo.report_id !== reportId)) {
        throw new Error("The photo list could not be verified.");
      }

      setPhotos(result);
      setLoaded(true);
      setRefreshRequired(false);
    } catch (caught) {
      if (mounted.current) {
        setError(errorMessage(caught));
        setRefreshRequired(true);
      }
    } finally {
      busy.current = false;

      if (mounted.current) {
        setLoading(false);
      }
    }
  }

  async function uploadPhoto() {
    if (
      busy.current ||
      !selectedFile ||
      !loaded ||
      refreshRequired ||
      status !== "pending" ||
      photos.length >= 3
    ) {
      return;
    }

    busy.current = true;
    setUploading(true);
    setError("");
    setMessage("");

    try {
      const uploaded = await uploadReportPhoto(
        reportId,
        selectedFile,
      );

      if (!mounted.current) return;

      if (uploaded.report_id !== reportId) {
        throw new Error("The uploaded photo could not be verified.");
      }

      setPhotos((current) => [
        ...current.filter((photo) => photo.id !== uploaded.id),
        uploaded,
      ]);

      clearSelection();
      setMessage("Photo uploaded successfully.");
    } catch (caught) {
      if (mounted.current) {
        setError(errorMessage(caught));
        setRefreshRequired(true);
      }
    } finally {
      busy.current = false;

      if (mounted.current) {
        setUploading(false);
      }
    }
  }

  const canSelect =
    loaded &&
    !refreshRequired &&
    status === "pending" &&
    photos.length < 3 &&
    !loading &&
    !uploading;

  return (
    <section className="report-photos" aria-label="Report photos">
      <h4>Photo evidence</h4>

      <button
        type="button"
        disabled={loading || uploading}
        onClick={() => void refreshPhotos()}
      >
        {loading
          ? "Loading photos..."
          : loaded
            ? "Refresh photos"
            : "Load photos"}
      </button>

      {!loaded && (
        <p>Load the photo list before adding a photo.</p>
      )}

      {loaded && <p>{photos.length} of 3 photos uploaded</p>}

      {loaded && photos.length === 0 && (
        <p>No photos have been uploaded for this report.</p>
      )}

      {photos.map((photo) => (
        <PhotoPreview
          key={photo.id}
          reportId={reportId}
          photo={photo}
        />
      ))}

      {status !== "pending" && (
        <p>Photos can only be added while a report is pending.</p>
      )}

      {loaded && photos.length >= 3 && (
        <p>This report has reached the limit of 3 photos.</p>
      )}

      {refreshRequired && (
        <p role="status">
          Refresh the photo list before attempting another upload.
        </p>
      )}

      {canSelect && (
        <div className="report-photo-inputs">
          <label className="form-field">
            <span>Take a photo</span>
            <input
              type="file"
              accept="image/jpeg,image/png"
              capture="environment"
              onChange={(event) => {
                selectPhoto(event.currentTarget.files?.[0]);
                event.currentTarget.value = "";
              }}
            />
          </label>

          <label className="form-field">
            <span>Choose from gallery</span>
            <input
              type="file"
              accept="image/jpeg,image/png"
              onChange={(event) => {
                selectPhoto(event.currentTarget.files?.[0]);
                event.currentTarget.value = "";
              }}
            />
          </label>

          <p>JPEG or PNG, up to 3 MiB per photo.</p>
          <p>Take photos only after stopping in a safe place.</p>
        </div>
      )}

      {localPreview && (
        <div>
          <p>Selected photo — upload is still required.</p>

          <img
            className="report-photo-image"
            src={localPreview}
            alt="Selected road condition photo before upload"
          />

          <div className="report-photo-actions">
            <button
              type="button"
              disabled={!canSelect || !selectedFile}
              onClick={() => void uploadPhoto()}
            >
              {uploading ? "Uploading..." : "Upload photo"}
            </button>

            <button
              type="button"
              disabled={uploading || loading}
              onClick={clearSelection}
            >
              Remove selection
            </button>
          </div>
        </div>
      )}

      {error && (
        <p className="form-message" role="alert">
          {error}
        </p>
      )}

      {message && (
        <p className="form-message" role="status">
          {message}
        </p>
      )}
    </section>
  );
}