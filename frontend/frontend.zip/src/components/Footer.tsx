import { Link } from 'react-router'

function Footer() {
  return (
    <footer className="site-footer">
      <Link className="brand" to="/">
        God<span className="brand-highlight">Eye</span>
      </Link>

      <Link to="/about">About GodEye</Link>

      <Link to="/admin">Reviewer access →</Link>
    </footer>
  )
}

export default Footer