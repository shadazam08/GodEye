import { Link, NavLink } from 'react-router'
import AuthControls from './AuthControls'

function Header() {
  return (
    <header className="site-header app-header">
      <Link className="brand" to="/" aria-label="GodEye home">
        <span className="brand-icon" aria-hidden="true">
          ◉
        </span>

        God<span className="brand-highlight">Eye</span>
      </Link>

      <nav
        className="app-navigation"
        aria-label="Main navigation"
      >
        <NavLink to="/" end>
          <span aria-hidden="true">🗺️</span>
          Map
        </NavLink>

        <NavLink to="/report">
          <span aria-hidden="true">📷</span>
          Report
        </NavLink>

        <NavLink to="/my-reports">
          <span aria-hidden="true">📋</span>
          My Reports
        </NavLink>
      </nav>

      <AuthControls />
    </header>
  )
}

export default Header