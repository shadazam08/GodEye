import { auth } from "../lib/firebase";
import { API_BASE_URL } from "../config";
import type { ReportRead, ReportStatus } from "../types/report";
import type { ReportPhoto, ReportPhotoPreview } from "../types/photos";

async function adminRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  if (!API_BASE_URL) {
    throw new Error("The API address is not configured.");
  }

  const user = auth.currentUser;

  if (!user) {
    throw new Error("Please sign in with your admin account.");
  }

  const uid = user.uid;
  const token = await user.getIdToken();

  if (auth.currentUser?.uid !== uid) {
    throw new Error("Your account changed. Please try again.");
  }

  const headers = new Headers(options.headers);
  headers.set("Authorization", `Bearer ${token}`);

  if (options.body !== undefined) {
    headers.set("Content-Type", "application/json");
  }

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 30_000);

  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers,
      signal: controller.signal,
      cache: "no-store",
      credentials: "omit",
    });

    if (auth.currentUser?.uid !== uid) {
      throw new Error("Your account changed. Reopen the dashboard.");
    }

    if (response.status === 401) {
      throw new Error("Please sign in again.");
    }

    if (response.status === 403) {
      throw new Error("This account does not have admin access. " + "Sign in with an authorized admin account.");
    }

    if (response.status === 404) {
      throw new Error("The report or photo was not found.");
    }

    if (response.status === 409) {
      throw new Error("This report has already been reviewed. Reload the queue.");
    }

    if (response.status === 422) {
      throw new Error("Check the review decision and reason.");
    }

    if (!response.ok) {
      throw new Error("The request could not be confirmed. " + "Reload the queue before retrying a decision.");
    }

    const result: T = await response.json();

    if (auth.currentUser?.uid !== uid) {
      throw new Error("Your account changed. Reopen the dashboard.");
    }

    return result;
  } catch (error) {
    if (
      error instanceof TypeError ||
      error instanceof SyntaxError ||
      (error instanceof DOMException && error.name === "AbortError")
    ) {
      throw new Error(
        "The request could not be confirmed. Check your connection " +
          "and reload the queue before retrying a decision.",
        { cause: error },
      );
    }

    throw error;
  } finally {
    window.clearTimeout(timeout);
  }
}

export function getAdminReports(
  offset = 0,
  reviewStatus: ReportStatus = "pending",
  mine = false,
): Promise<ReportRead[]> {
  const query = new URLSearchParams({
    review_status: reviewStatus,
    mine: String(mine),
    limit: "50",
    offset: String(offset),
  });

  return adminRequest<ReportRead[]>(`/api/admin/reports?${query}`);
}

export function saveAdminReview(
  reportId: string,
  decision: "verified" | "rejected",
  reason: string,
): Promise<ReportRead> {
  return adminRequest<ReportRead>(`/api/admin/reports/${encodeURIComponent(reportId)}/review`, {
    method: "PATCH",
    body: JSON.stringify({
      status: decision,
      reason: reason.trim(),
    }),
  });
}

export function getAdminPhotos(reportId: string): Promise<ReportPhoto[]> {
  return adminRequest<ReportPhoto[]>(`/api/admin/reports/${encodeURIComponent(reportId)}/photos`);
}

export function getAdminPhotoPreview(reportId: string, photoId: string): Promise<ReportPhotoPreview> {
  return adminRequest<ReportPhotoPreview>(
    `/api/admin/reports/${encodeURIComponent(reportId)}` + `/photos/${encodeURIComponent(photoId)}/preview`,
  );
}

export type AdminReviewEvent = {
  id: string
  report_id: string
  previous_status: ReportStatus
  new_status: 'verified' | 'rejected'
  reviewer_uid: string | null
  reviewer_label: string
  reason: string
  created_at: string
}

export function getAdminReviewHistory(
  reportId: string,
  offset = 0,
): Promise<AdminReviewEvent[]> {
  const query = new URLSearchParams({
    limit: '50',
    offset: String(offset),
  })

  return adminRequest<AdminReviewEvent[]>(
    `/api/admin/reports/${encodeURIComponent(reportId)}` +
      `/history?${query}`,
  )
}